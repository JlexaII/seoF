<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title><?php echo $__env->yieldContent('titles'); ?></title>
</head>

<body class="min-h-screen bg-gray-50">
    <?php echo $__env->yieldContent('sidebar'); ?>

    <?php echo $__env->yieldContent('content'); ?>
</body>

</html>

<style>
    body {
        background-image: url(images/5594016.jpg);
    }
</style>
<?php /**PATH C:\OSPanel\domains\seoF\resources\views/layouts/app.blade.php ENDPATH**/ ?>