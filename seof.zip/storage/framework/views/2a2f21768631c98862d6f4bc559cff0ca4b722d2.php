<header class="flex items-center justify-between p-6">
    <a href="/" class="flex items-center gap-2">
        <img class="h-10 text-green-600" src="images/SF.png" alt="SF">
        <span class="text-xl font-black">SeoFast</span>
    </a>
    <div>
        <a href="<?php echo e(route('yangi')); ?>"
            class="rounded-md bg-gray-200 py-2 px-4 font-semibold text-red shadow-lg transition duration-150
            ease-in-out hover:bg-green-700 hover:shadow-xl focus:shadow-xl focus:outline-none focus:ring-2 focus:ring-green-500
            focus:ring-offset-2">Yangiliklar</a>
        <a href="<?php echo e(route('narx')); ?>"
            class="rounded-md bg-gray-200 py-2 px-4 font-semibold text-red shadow-lg transition duration-150 ease-in-out
            hover:bg-green-700 hover:shadow-xl focus:shadow-xl focus:outline-none focus:ring-2 focus:ring-green-500
            focus:ring-offset-2">Narxlar</a>
        <a href="<?php echo e(route('bizh')); ?>"
            class="rounded-md bg-gray-200 py-2 px-4 font-semibold text-red shadow-lg transition duration-150
            ease-in-out hover:bg-green-700 hover:shadow-xl focus:shadow-xl focus:outline-none focus:ring-2 focus:ring-green-500
            focus:ring-offset-2">Biz haqimizda</a>
    </div>
    <div>

    </div>
    <div>
        <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('login')); ?>"
                class="rounded-md bg-gray-200 py-2 px-4 font-semibold text-gray-900 shadow-lg transition duration-150 ease-in-out hover:bg-gray-300 hover:shadow-xl focus:shadow-xl focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2">Kirish</a>
            <a href="<?php echo e(route('register')); ?>"
                class="rounded-md bg-green-600 py-2 px-4 font-semibold text-white shadow-lg transition duration-150 ease-in-out hover:bg-green-700 hover:shadow-xl focus:shadow-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2">Ro`yhat</a>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('dashboard')); ?>"
                class="rounded-md bg-gray-200 py-2 px-4 font-semibold text-gray-900 shadow-lg transition duration-150 ease-in-out hover:bg-gray-300 hover:shadow-xl focus:shadow-xl focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2">Kabinet</a>
        <?php endif; ?>
    </div>
</header>
<?php /**PATH C:\OSPanel\domains\seoF\resources\views/inc/header.blade.php ENDPATH**/ ?>