@extends('layouts.app')

@section('titles')
    SeoFast
@endsection

@section('content')
    @include('inc.header')
    @include('inc.sidebar')
@endsection
