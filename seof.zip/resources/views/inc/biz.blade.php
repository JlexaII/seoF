@extends('layouts.app')

@section('titles')
Biz haqimizda
@endsection

@section('content')
@include('inc.header')
<h1>Biz haqimizda</h1>
@endsection
