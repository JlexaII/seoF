@extends('layouts.app')

@section('titles')
Yangiliklar
@endsection

@section('content')
@include('inc.header')
<h1>Yangiliklar</h1>
@endsection

