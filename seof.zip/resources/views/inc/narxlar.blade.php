@extends('layouts.app')

@section('titles')
Narxlar
@endsection

@section('content')
@include('inc.header')
<h1>Barcha narx navo</h1>
@endsection
